package com.narendra;
import java.util.Scanner;
public class RectangleDemo 
{
	

	    int length; 
	    int breadth; 
	    int area; 
	   
	    public RectangleDemo()
	    {
	    	length = 0;
	    	breadth= 0;
	    }

	    void input() {
			Scanner in = new Scanner(System.in);
			System.out.print("Enter length of rectangle: ");
			length = in.nextInt();
	        System.out.print("Enter breadth of rectangle: ");
	        breadth = in.nextInt();
	    }

	    void calculate() {
	        area = length * breadth;
	        
	    }

	    void display() {
	        System.out.println("Area of Rectangle = " + area);
	       
	    }

	    public static void main(String args[]) {
	        RectangleDemo obj1 = new RectangleDemo();
	        obj1.input();
	        obj1.calculate();
	        obj1.display();
	        System.out.println("****************************");
	        RectangleDemo obj2 = new RectangleDemo();
	        obj2.input();
	        obj2.calculate();
	        obj2.display();
	        System.out.println("****************************");
	        RectangleDemo obj3 = new RectangleDemo();
	        obj3.input();
	        obj3.calculate();
	        obj3.display();
	        System.out.println("****************************");
	        RectangleDemo obj4 = new RectangleDemo();
	        obj4.input();
	        obj4.calculate();
	        obj4.display();
	        System.out.println("****************************");
	        RectangleDemo obj5 = new RectangleDemo();
	        obj5.input();
	        obj5.calculate();
	        obj5.display();
	    }
	}


