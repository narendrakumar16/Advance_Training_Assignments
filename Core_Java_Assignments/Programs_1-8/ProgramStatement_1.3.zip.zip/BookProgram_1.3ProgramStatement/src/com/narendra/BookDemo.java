package com.narendra;

public class BookDemo 
{

String Book_tittle;
	double Book_price;
	
	public BookDemo(String Book_tittle, double Book_price)
	{
		this.Book_tittle= Book_tittle;
		this.Book_price = Book_price;
	}
	
	public String getBookDemo_tittle() {
		return Book_tittle;
	}
	public void setBook_tittle(String Book_tittle) {
		this.Book_tittle = Book_tittle;
	}
	public double getBook_price() {
		return Book_price;
	}
	public void setBookDemo_price(double BookDemo_price) {
		this.Book_price = BookDemo_price;
	}
	
	 public void display(){
	      System.out.println("Book_title: "+this.Book_tittle);
	      System.out.println("Book_price: "+this.Book_price);
	      
	   }
	
}



